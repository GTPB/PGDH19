pairwise = function(m1)
{
	d1 = dist(m1,method="man") #we use a manhattan distance because this corresponds 
								#the pairwise difference 
	mean(d1) #as long as we use a manhattan distance the mean is unaffected by phase 
	         #but not any higher moments, which are strongly affected.
}

make.single = function(a)
{
	nhap = length(a[,1])
	nind = floor(nhap/2)
	if(nhap != 2*nind)stop("make.single: number of haplotypes is not even")
	nsnp = length(a[1,])
	h1 = a[seq(1,nhap,by=2),]
	h2 = a[seq(2,nhap,by=2),]
	s1 = h1 + h2
	s1
}

pairwise.sing = function(s)
{
	d1 = dist(s) #this is for the genotype (0,1,2) data. We are going to use this
	             #to get summary of distribution. We are happy with standard Euclidean
	             #distance for this
	a1 = mean(d1)
	a2 = sd(d1)
	a3 = quantile(d1,c(0.01,0.05,0.1,0.2,0.5,0.8,0.9,0.95,0.99))
	as.numeric(c(a1,a2,a3))
	
}

fspec = function(s,wrap=T)
#gives the frequency spectrum, folde by default
{
	nsnp = length(s[1,])
	nhap = length(s[,1])*2
	freqs = apply(s,2,sum)
	t1 = table(freqs)
	#return(t1)
	f1 = as.numeric(names(t1))
	c1 = as.numeric(t1)
	if(min(f1) == 0 || max(f1) == nhap){ #we need to remove the monomorphic ones
		if(min(f1) == 0){
			f1 = f1[-1]
			c1 = c1[-1]	
		}
		if(max(f1) == nhap){
			f1 = f1[-length(f1)]
			c1 = c1[-length(c1)]	
		}
		if(length(f1)!=length(c1))stop("fspec: f1,c1 have different lengths")
		if(length(f1) > nhap-1)stop("fspec: f1,c1 too long")
	}
	#So f1 has entries in 1...nhap-1 for sites that have 1...nhap-1 copies of the '1' allele
	#c1 has entries for each element of f1 giving the number of SNPs that have the configuration given by f1

	#f2 = c(1:(nhap-1)) actually redundant, corresponds to c2

	c2 = rep(0,nhap-1) # do this to create the default number of counts for the full 1...nhap-1 (in f2 above)
	c2[f1] = c1 #fill with the actual observed entries
	if(wrap){ #this is if we use the folded spectrum (default)
		c3 = c2 + rev(c2)
		c3[nhap/2] = c3[nhap/2]/2 #because this is the one it wraps around, so duplicated
		return(c3[1:(nhap/2)])
	}
	return(c2)
	
}

summarise_fspec = function(v)
#v is the frequency spectrum- sequence of SNP counts for singletons onwards (either folded or unfolded)
{
	ip = length(v) #this will either be sample size (nhap, above) minus one - or sample size divided by two
                       #depending on whether it is folded or unfolded
	if(ip <= 10)stop("summarise_fspec: currently assumes spectrum has length greater than 10")
			#i.e. we are assuming sample size > 20 (folded) or > 11 (unfolded)
	q1 = ceiling(rep(ip,6)/c(ip,10,5,2.5,1.75,1.25))
	a1 = cumsum(v)/sum(v) # so a1 is the same length as v
	a1[q1] #return only the cumulative proportion of the frequency spectrum from 1 to (size of spectrum)/1.25
               #still not entirely clear why I chose this set of summary stats; appears to give a roughly uniform
               #set of probs
}


getcovs = function(m1,nmax=dim(m1)[2],thresh)
{
	#Still needs to be improved - too many small entries
	#if input matrix m1 is too big take an ordered random subset of the columns
	w1 = apply(m1,2,sd)
	w1 = w1 > thresh
	if(sum(w1) <2)return(c(0,0,0))
	#print(nmax)
	m1 = m1[,w1]
	if(nmax < dim(m1)[2]){
		ivec = sort(sample.int(dim(m1)[2],nmax))
		m1 = m1[,ivec]		
	}
	xx = cor(m1) #cov or cor?
	utri = upper.tri(xx)
	c1 = abs(xx[utri])
	#as.numeric(quantile(c1,seq(0.5,0.99,len=3)))
	as.numeric(quantile(c1,c(0.5,0.9)))
}


