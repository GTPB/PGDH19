#The following example will attempt to fit an IM model for the river and lake Itamba populations
#The parameters that we will estimate are:
#log(4N_1.mu)
#log(4N_2.mu)
#log(4N_anc.mu)
#log(4N_1.r) (N_1 is the reference pop - i.e. an ms convention)
#log(4N_1.mig_12)
#log(4N_2.mig_21)
#log(mu.t_join) - the time back when the populations were joined

#where mig_ij is the fraction of subpopulation i which is made up of migrants from subpopulation 
#j each generation.

#The SNP positions from the pcadapt analysis can be obtained as:

posit = scan("positions.txt")

#We will choose the set of SNPs that are found from positions between 1Mb to 1.1Mb from the start of scaffold
#10 from the Itamba and river cichlids. I.e. just 100kb. This is simply to make calculations quicker


#We can obtain these from the commands:
cs = which(posit > 1e6 & posit < 1.1e6)
#> length(cs)
#[1] 751

#giving us 751 snps. 

#We can then choose these from the real data

#First we have to read in the real data that we generated using vcftools
data.set = read.table("itamba_river_scaff10_seqs.impute.hap")


#These are individuals we used for this subset - remember we are sticking to the 
#river Calliptera (first 32 sequences) and Itamba (last 60 sequences)
keep.label = scan("keep_indiv.txt",what="") #should have been made in the previous script

#This is the full data matrix:

dim(data.set)
#[1] 64986    92

#You can see that it contains the same number of SNPs as the full data set for all cichlids.

#We then select the target data set we will use
target.data = data.set[cs,]

#but this is in the vcftools orientation, so we transpose it, so that rows correspond to sequences.
target.data = t(target.data)

dim(target.data)
#[1] 92   751

#Note that the samples contain 32 river sequences followed by 60 river sequences. 
#We can get the summary statistics for the target data set using
source("scrm_abc.R")
source("R_funcs.R")
target.ss = getss(target.data,32,60)
#Note that here since we don't have information on the ancestral nucleotide at each SNP
#we will only work with the folded site frequency spectrum

#The summary statistics used here are arbitrary, and described in detail in the function description. 
#The function has been modified for this course to drop some time-consuming calculations
#You are welcome to edit it to choose better summary statistics, or add in the commented out
#ones - but you will need to make edits on the space allocated to ensure nothing is broken
#Broadly, the strategy is that summary statistics are computed for combined individuals from both populations,
#and then individually for the populations.
#Two basic sets of statistics are computed: 
#The mean, sd, and 9 quantiles of the distribution of pairwise euclidean distances between individuals
#6 quantiles of the frequency spectrum
#This gives 3 X 11 + 3 X 6 = 51 summary statistics

#To simulate data for the ABC analysis, we will use the simulator scrm(), which is a fast and flexible 
#simulator that we can call directly in R.
#You will need:
library(scrm) #install if necessary
#As currently implemented the function specifies the priors within its body - so will need to be edited, if 
#you wish to modify. The priors are specied as Gaussian (normal) for these log-scaled parameter values:
#	ltheta0 = rnorm(num_abc_sims,log(50),1)
#	ltheta1 = rnorm(num_abc_sims,log(50),1)
#	ltheta_anc = rnorm(num_abc_sims,log(50),1)
#	lrho = rnorm(num_abc_sims,log(10),1.5)
#	lM_12 = rnorm(num_abc_sims,log(1),1.5)
#	lM_21 = rnorm(num_abc_sims,log(1),1.5)
#	lmuT = rnorm(num_abc_sims,log(50),1)

#The following should take around 30 minutes on the machines (a bit of a guess)

res1 <- scrm_abc(50000,100000,32,60)
#note that this is still a small number for ABC, and ideally should be from an overnight run.

#After you have started the run. We will go back to the lecture, to introduce the material used below.

################################################################################################

#The ABC analysis

#In this example we will use the abc package:
library(abc) #install if necessary
#As explained the vignette starts with model choice, and leads you to first choose the correct model, and 
#examine goodness of fit, and then make the parameter estimates. 
#However we will start with parameter estimates, and goodness of fit, and ignore model choice in this example.
#A good method for implementing it would be to copy the scrm_abc to a new function, and set the migration rates
#to zero - i.e. compare a splitting model with a splitting plus migration model; another obvious model
#is to drop the split time from the model - so it becomes an island model with migration. 

#To fit parameters:

abc.res = abc(target = target.ss,param=res1$params,sumstat=res1$sumstat,tol=0.05,method="neuralnet")

#Following the vignette we can do the following (these will invite you to press 'return' for each parameter):
hist(abc.res)
plot(abc.res,param=res1$params)


#To use PCA to look at goodness of fit:
mymod = rep("IM",length(res1$sumstat[,1]))
gfitpca(target=target.ss,sumstat=res1$sumstat,cprob=0.1,index=mymod)
#(note index is a required parameter, even if you only have one model)
#This uses pca on the distribution of simulated summary statistics, and shows the position 
#of the target summary statistics on the first two components. The contour is the 90% highest
#posterior density limit.

#This function will perform cross-validation on a sample of 10 data sets with parameters 
#taken over the range of the prior to see how well the method can recover parameter estimates.

op = par(mfrow = c(4, 2), # 4x2 layout
oma = c(2, 2, 2, 2), # two rows of text at the outer left and bottom margin
mar = c(1, 1, 2, 2), # space for one row of text at ticks and to separate plots
mgp = c(2, 1, 0)) # axis label at 2 rows distance, tick labels at 1 row

for(j in 1:7){
cv.reg = cv4abc(res1$params[,j],res1$sumstat,nval=10,tols=c(0.01,0.05,0.1),method="loclinear")
plot(cv.reg)
}

par(op)

#You can explore range of further examples in the vignette using these data, or the human Sanger-sequence
#data from Voight et al (2005), and follow the vignette more closely.

#In addition, if you are interested in using semi-automatic ABC - i.e. working with projected 
#summary statistics - I have found that the abctools package requires quite a lot of work to use
#effectively. It also has a number of methods for optimally choosing a subset of summary statistics to
#use. Instead I have written a simple pair of functions that first compute the projection for a
#data set, and then can be used to apply to the target set of summary statistics and other set of summary 
#statistics, or, using the data twice can be applied to the original set of statistics again, as in the 
#example below. It is probably better if the data set used to compute the projections is different from 
#the final dataset, to avoid overfitting. These can be used as:
source("fp_proj.R")
proj.mat = get_fp_proj(sstable=res1$sumstat,params=res1$params) #make the projection matrix
sstable.proj = make_fp_proj(proj.mat,res1$sumstat) #project the summary statistics
target.proj = make_fp_proj(proj.mat,target.ss) # project the target

#We can see if the regressions have any predictive power on the parameter values.
op = par(ask=T)
for(j in 1:7)plot(res1$params[,j],sstable.proj[,j],main=j)
par(op)

#you can see if this makes any improvement in estimation using abc 
#What happens if you repeat the steps above to with this new set of summary statistics and target?


