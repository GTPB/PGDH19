#Analysis of cichlid data

#Download the vcf file Massoko_Dryad_VCF_final.vcf.gz from Dryad: 
#https://datadryad.org/bitstream/handle/10255/dryad.101389/Massoko_Dryad_VCF_final.vcf.gz?sequence=1

#This dataset is rather too large to easily be handled for this ABC excercise
#(about 5 million SNPs, 150 individuals)

#However, we can look at individual scaffolds (contiguous sections of DNA sequence, not yet assigned to chromosomes) using vcftools:

#The largest in the cichlid vcf file is scaffold 0, with several hundred thousand SNPs. 
#However, to be manageable I have chosen scaffold 10 using the following command

#vcftools --gzvcf Massoko_Dryad_VCF_final.vcf.gz --chr scaffold_10 --recode --out Massoko_scaff10

#I have also used the following command to obtain a list of the names of individuals, so I know where they come from

#vcftools --gzvcf Massoko_Dryad_VCF_final.vcf.gz --chr scaffold_10 --012 --out Massoko_scaff10

#This created the following files:

#Massoko_scaff10.012
#Massoko_scaff10.012.indv
#Massoko_scaff10.012.pos

#and the first few lines of Massoko_scaff10.012.indv are:
#A_calliptera_Bua
#A_calliptera_Chitimba
#A_calliptera_Chizumulu
#A_calliptera_Enukweni
#A_calliptera_Kitai_Dam
#A_calliptera_Lake_Chidya
#A_calliptera_Lake_Chilwa
#A_calliptera_Luwawa
#A_calliptera_Mbaka_river_Female
#A_calliptera_Near_Kyela

#We will first look at the structure using pcadapt

library(pcadapt)
fname = read.pcadapt("Massoko_scaff10.recode.vcf",type="vcf",allele.sep = "|")
test1 = pcadapt(fname,K=10)
#I created labels for the individuals just by eye looking at Massoko_scaff10.012.indv rather than fancy programming (also possible...)
ind.label = c(rep("River Calliptera",16),rep("Itamba",(46-17+1)),rep("Benthic Massoko",83-47+1),rep("Littoral Massoko",115-84+1),rep("Small Massoko",146-116+1))
#This creates a vector with entries corresponding to 
# River Calliptera
# Itamba
# Benthic Massoko
# Littoral Massoko
# Small Massoko

#From this we can then look at the pop structure 
#E.g. 
plot(test1,option="scores",pop=ind.label) 

#NB
#For looking at outliers you may want to choose the correct number of components using a scree plot. The plot of the scores suggests 2 or 3 is a good choice of K. 

#However we are doing this just to look at the data prior to an ABC analysis. 
#We can see the Massoko fish are very similar (complicated story, look at original paper)
#So let us concentrate on the Itamba/River Calliptera and ask when Itamba may have been founded (equating this to estimated divergence time), and whether
#there has been any gene flow. I.e. fit an IM model.

#So we first want to choose the subset of individuals from Itamba or rivers
#I will do this again using vcftools, but it would probably be possible to use bed2matrix() from pcadapt

#(!!!NB you need to make this file for the next script!!!)Next, perform the following:
#The .indv file (Massoko_scaff10.012.indv) must be edited to make "keep_indiv.txt" using only rivers and itamba (first 92 lines)

#(For interest, only, no need to perform:)An example command which gives a recoded vcf file is
#vcftools --gzvcf Massoko_Dryad_VCF_final.vcf.gz --chr scaffold_10 --keep keep_indiv.txt --recode --out itamba_river_scaff10

#Actually we want the SNP information which we can get from 
#vcftools --gzvcf Massoko_Dryad_VCF_final.vcf.gz --chr scaffold_10 --keep keep_indiv.txt --IMPUTE --out itamba_river_scaff10_seqs
#Note that the vcf file on Dryad is only loosely phased, so probably a bit suspect, and so we will not use this information in computation
#Additionally the vcf file does not contain reliable ancestral data, so we will not assume we can distinguish ancestral and derived alleles





