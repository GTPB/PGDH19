scrm_abc = function(num_abc_sims,len,num1,num2)
{
	#priors:
	#remember: in ms M_ij is 4N0 times the fraction of subpopulation i which is made up of migrants from subpopulation j each generation
	# example: -ma M_11 M_12 M_21 M_22, where we can have x in place of M_11 and M_22 because whatever is here is ignored by ms. 
	#so we need to divide by popscale2 to make sure it is right for scrm. 
	
	ss = matrix(nrow=num_abc_sims,ncol=51)
	
	tothap = num1+num2
	
	ltheta0 = rnorm(num_abc_sims,log(50),1)
	ltheta1 = rnorm(num_abc_sims,log(50),1)
	ltheta_anc = rnorm(num_abc_sims,log(50),1)
	lrho = rnorm(num_abc_sims,log(10),1.5)
	lM_12 = rnorm(num_abc_sims,log(1),1.5)
	lM_21 = rnorm(num_abc_sims,log(1),1.5)
	lmuT = rnorm(num_abc_sims,log(50),1)
	paramlist = cbind(ltheta0,ltheta1,ltheta_anc,lrho,lM_12,lM_21,lmuT)
	#print("got here 1")
	for(iter in 1:num_abc_sims){
		theta0 = exp(paramlist[iter,1])
		popscale2 = exp(paramlist[iter,2])/theta0
		popscale_anc = exp(paramlist[iter,3])/theta0
		rho = exp(paramlist[iter,4])
		M_12 = exp(paramlist[iter,5])
		M_21 = exp(paramlist[iter,6])/popscale2 #(to make sure scaled by N0)
		T1 = exp(paramlist[iter,7])/theta0

		command = paste(tothap, 1, "-r", rho,len,"-t",theta0,"-I",2,num1,num2,"-ma","x",M_12,M_21,"x","-n",2,popscale2,"-ej",T1,1,2,"-en",T1,2,popscale_anc)
		t1 <- scrm(command)
		ss[iter,] = getss(t1$seg_sites[[1]],num1,num2)
	}

	list(params=paramlist,sumstat=ss)
}

getss = function(geno.both,num1,num2)
#geno.both is 'both' because it contains both populations

{
#sumstat = numeric(65)
sumstat = numeric(51)
thresh = 0.01
pop1.chroms = c(1:num1)
pop2.chroms = c((num1+1):(num1+num2))
pop1 = c(1:(num1/2))
pop2 = c((num1/2+1):((num1+num2)/2))

gt = make.single(geno.both) #we will ignore phase and create 0,1,2 data
#sumstat[1] =  pairwise(geno.both) # pi for all data regardless of pop
#sumstat[2] =  pairwise(geno.both[pop1.chroms,]) #pi for pop1
#sumstat[3] =  pairwise(geno.both[pop2.chroms,]) #pi for pop2
#sumstat[4] = sumstat[2] / sumstat[1] #ratio pi pop1 to all
#sumstat[5] = sumstat[3] / sumstat[1] #ratio pi pop2 to all
#sumstat[6] = length(geno.both[1,]) #number of snps - number of mutations, both pops
#sumstat[7] = sum(apply(geno.both[pop1.chroms,],2,var) > 0) #num snps pop1
#sumstat[8] = sum(apply(geno.both[pop2.chroms,],2,var) > 0) #num snps pop2
sumstat[1:11] = pairwise.sing(gt) #distribution sum stats for euclidean pairwise distance
sumstat[12:22] = pairwise.sing(gt[pop1,]) #distribution sum stats for pop1
sumstat[23:33] = pairwise.sing(gt[pop2,]) #distribution sum stats for pop2
sumstat[34:39] = summarise_fspec(fspec(gt)) #summary quantiles of freq spectrum both pops (folded by default)
sumstat[40:45] = summarise_fspec(fspec(gt[pop1,])) #summary for pop1
sumstat[46:51] = summarise_fspec(fspec(gt[pop2,])) #summary of pop2
#print("here")
#sumstat[60:61] = getcovs(gt,thresh=thresh) 
#sumstat[62:63] = getcovs(gt[pop1,],thresh=thresh)
#sumstat[64:65] = getcovs(gt[pop2,],thresh=thresh)

sumstat

}
