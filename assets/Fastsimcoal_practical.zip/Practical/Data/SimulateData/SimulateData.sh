#!/bin/bash

# Path to fastsimcoal2
fscPath="../../fastsimcoal2/fsc_linux64/fsc25221"

chmod +x $fscPath

for file in *.par
do
	#Running fastsimcoal
	$fscPath -i ${file} -n 1 -d -I -x -q -s0
done
