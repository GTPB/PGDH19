The source code for ms can be downloaded here:

http://home.uchicago.edu/rhudson1/source/mksamples.html

In this folder you can find the documentation of ms as well as a compiled version